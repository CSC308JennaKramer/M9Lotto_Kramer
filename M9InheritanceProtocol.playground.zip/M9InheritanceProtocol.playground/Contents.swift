import UIKit

/*
 Iheritance: sub class, super class
 sub class can be inherited with all characteristics of super class
 allow single inheritance only
 
 class sub_class: super_class{
 
 }
 */

class Man{
    var age: Int
    var weight: Double
    
    init(age: Int, weight: Double){
        self.age = age
        self.weight = weight
    }
    
    func display(){
        print("age = \(age) and weight = \(weight)")
    }
}

extension Man{
    func sayHello(){
        print("Hello, I am \(age) years old and weigh \(weight) kg")
    }
}

var man: Man = Man(age: 20, weight: 70)
man.display()
man.sayHello()


class Student: Man{
    var name: String
    
    init(name: String, age: Int, weight: Double){
        self.name = name
        super.init(age: age, weight: weight)
    }
    
    override func display(){
        print("name: \(name), age: \(age), and weight: \(weight)")
    }
}

var student: Student = Student(name: "John", age: 20, weight: 70)
student.display()

/*
 protocol: Blueprint of properties and methods
 
 protocol ProtocolName{
    properties
    methods
 }
 

//protocol: -able, datasource, delegate
*/

protocol Runnable{ //1. declare
    var x: Int{get set}
    func run()
}

class Woman: Runnable{ //2. adopt
    //3. confirm
    var x: Int = 1
    func run(){
        print("running~")
    }
}

let runner = Woman()
print(runner.x)
runner.run()


protocol SomeProtocol{
    var x: Int{get set}
    func random() -> Int
}

class ProtoBox{
    var x: Int = 0
    func random() -> Int{
        return Int.random(in: 0 ... 9)
    }
}

let p = ProtoBox()
print(p.x)
print(p.random())

class Ta: Student{
        
}

//class: class, protocol, protocol
//class: protocol, protocol, protocol
class Athelete: Man, Runnable{ //#2
    //#3
    var x: Int = 1
    func run() {
        print("Athelete running with x = \(x)")
    }
}
let athelete: Athelete = Athelete(age: 20, weight: 70)
athelete.display()
athelete.run()

//class: class, protocol, protocol
class PowerStudent: Student, Runnable, SomeProtocol{
    //Runnable Protocol
    var x: Int = 2
    
    override init( name: String, age: Int, weight: Double){
        super.init(name: name, age: age, weight: weight)
    }
    
    func run(){
        print("PowerStudent running. x = \(x)")
    }
    //SomeProtocol
    func random() -> Int{
        return 7
    }
}

let ps = PowerStudent(name: "John", age: 20, weight: 70)
ps.display()
ps.run()
print(ps.random())

class Jogger: Runnable{
    var x: Int = 3
    func run() {
        print("Jogger running slowly, x = \(x)")
    }
}
let jogger: Jogger = Jogger()
jogger.run()

class DualBox: Runnable, SomeProtocol{
    var x: Int = 11
    func run() {
        print("DualBox running. x = \(x)")
        
    }
    func random() -> Int {
        return 9
    }
}

let db = DualBox()
db.run()
print(db.random())

class Animal{
    var name: String
    var age: Int
    init(name: String, age: Int){
        self.name = name
        self.age = age
    }
    func sound(){
        print("Some sound...")
    }
}
class Dog: Animal{
    override func sound() {
        print("\(name) syas woof!")
    }
}

extension Animal{
    func info() -> String{
        return "\(name) is \(age) years old."
    }
}
let d = Dog(name: "Buddy", age: 3)
d.sound()
print(d.info())


protocol Flyable{
    func fly()
}

class Bird: Flyable{
    func fly() {
        print("Bird Flying")
    }
}

extension Bird{
    func land(){
        print("Bird Landed")
    }
}

let b = Bird()
b.fly()
b.land()


class Person{
    var name: String
    init(name: String) {
        self.name = name
    }
    func greet(){
        print( "Hello, I am \(name).")
    }
}

protocol Workable {
    func work()
}
class Teacher: Person, Workable {
    func work(){
        print("\(name) is teaching.")
    }
}

let t = Teacher(name: "Alice")
t.greet()
t.work()


protocol Drawable {
    func draw()
}

class Shape: Drawable {
    func draw(){
        print("Drawing a shape")
    }
    
    func area() -> Double{
        return 0.0
    }
}

class Circle: Shape {
    var radius: Double
    init(radius: Double) {
        self.radius = radius
    }
    override func area() -> Double {
        return 3.14 * radius * radius
    }
    
    override func draw(){
        print("Drawing a circle")
    }
}

extension Circle {
    func diameter() -> Double {
        return radius * 2
    }
}


let c = Circle(radius: 5.0)
c.draw()
print( "Area: \(c.area())")
print( "Diameter: \(c.diameter())")


protocol Playable {
    func play()
}

protocol Scorable {
    var score: Int { get set }
}

class GamePlayer: Playable, Scorable {
    var score: Int = 0
    func play() {
        score += 10
        print("Score = \(score)")
    }
}

extension GamePlayer {
    func reset(){
        score = 0
        print("reset to 0")
    }
}

let gp = GamePlayer()
gp.play()
gp.reset()
print("Current Score: \(gp.score)")

class: class, protocol {
    
}
